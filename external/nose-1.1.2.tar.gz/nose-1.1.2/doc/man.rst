===========
 nosetests
===========

------------------------
nicer testing for python
------------------------

:Author: jpellerin+nose@gmail.com
:Date:   2009-04-23
:Copyright: LGPL
:Version: 0.11
:Manual section: 1
:Manual group: User Commands

SYNOPSIS
========

  nosetests [options] [names]

DESCRIPTION
===========

.. autohelp ::
