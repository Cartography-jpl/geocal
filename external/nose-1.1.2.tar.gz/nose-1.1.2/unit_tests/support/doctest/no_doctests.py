"""
Module without doctests.
"""
def foo():
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()
