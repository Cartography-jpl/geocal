Testid: add a test id to each test name output
==============================================

.. autoplugin :: nose.plugins.testid
