# load extended setup modules for distuils

from install_data_ext import install_data_ext
